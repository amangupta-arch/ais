/* eslint-disable */
/* Shared icons + tiny helpers used across specimen artboards.
   Exposes: Icons, Logo, Wordmark, PhoneFrame, BrandBadge, FlowDots
   Assigned to window at end of file.
*/

const Icons = {
  bolt:   <svg className="icon" viewBox="0 0 24 24"><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/></svg>,
  mic:    <svg className="icon" viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4M8 22h8"/></svg>,
  book:   <svg className="icon" viewBox="0 0 24 24"><path d="M4 4h10a4 4 0 0 1 4 4v12H8a4 4 0 0 1-4-4V4z"/><path d="M4 4v12a4 4 0 0 1 4-4h10"/></svg>,
  play:   <svg className="icon" viewBox="0 0 24 24"><path d="M6 4l14 8-14 8V4z"/></svg>,
  pause:  <svg className="icon" viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>,
  check:  <svg className="icon" viewBox="0 0 24 24"><path d="M5 12l5 5 9-12"/></svg>,
  x:      <svg className="icon" viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>,
  flame:  <svg className="icon" viewBox="0 0 24 24"><path d="M12 3s4 5 4 9a4 4 0 0 1-8 0c0-2 1-3 2-4 0 2 2 2 2 0 0-2-2-3 0-5z"/></svg>,
  star:   <svg className="icon" viewBox="0 0 24 24"><path d="M12 3l2.7 6 6.3.6-4.8 4.2 1.5 6.2L12 17l-5.7 3 1.5-6.2L3 9.6 9.3 9z"/></svg>,
  heart:  <svg className="icon" viewBox="0 0 24 24"><path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.5-7 10-7 10z"/></svg>,
  home:   <svg className="icon" viewBox="0 0 24 24"><path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7h-6v7H4a1 1 0 0 1-1-1V11z"/></svg>,
  chat:   <svg className="icon" viewBox="0 0 24 24"><path d="M4 5h16v11H8l-4 4V5z"/></svg>,
  avatar: <svg className="icon" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>,
  globe:  <svg className="icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>,
  search: <svg className="icon" viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>,
  settings: <svg className="icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5h0a1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>,
  arrowRight: <svg className="icon" viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>,
  arrowLeft:  <svg className="icon" viewBox="0 0 24 24"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>,
  plus:   <svg className="icon" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>,
  volume: <svg className="icon" viewBox="0 0 24 24"><path d="M11 5L6 9H3v6h3l5 4V5zM16 9a5 5 0 0 1 0 6M19 6a9 9 0 0 1 0 12"/></svg>,
  trophy: <svg className="icon" viewBox="0 0 24 24"><path d="M8 3h8v5a4 4 0 0 1-8 0V3zM5 3v3a3 3 0 0 0 3 3M19 3v3a3 3 0 0 1-3 3M10 14h4v4h2v2H8v-2h2v-4z"/></svg>,
  sparkle: <svg className="icon" viewBox="0 0 24 24"><path d="M12 3l1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5L12 3zM19 15l.8 2.7L22 18l-2.2.8L19 21l-.8-2.3L16 18l2.2-.8L19 15z"/></svg>,
  lock:   <svg className="icon" viewBox="0 0 24 24"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 1 1 8 0v3"/></svg>,
  clock:  <svg className="icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>,
  menu:   <svg className="icon" viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg>,
  more:   <svg className="icon" viewBox="0 0 24 24"><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></svg>,
  wave:   <svg className="icon" viewBox="0 0 24 24"><path d="M2 12h2M6 7v10M10 4v16M14 8v8M18 10v4M22 12h0"/></svg>,
  headphones: <svg className="icon" viewBox="0 0 24 24"><path d="M4 14a8 8 0 0 1 16 0v4a2 2 0 0 1-2 2h-2v-6h4M4 14v4a2 2 0 0 0 2 2h2v-6H4"/></svg>,
  eye: <svg className="icon" viewBox="0 0 24 24"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/></svg>,
  brain: <svg className="icon" viewBox="0 0 24 24"><path d="M9 3a3 3 0 0 0-3 3v1a3 3 0 0 0-2 3 3 3 0 0 0 1 2 3 3 0 0 0 1 4 3 3 0 0 0 3 2 3 3 0 0 0 3-3V3zM15 3a3 3 0 0 1 3 3v1a3 3 0 0 1 2 3 3 3 0 0 1-1 2 3 3 0 0 1-1 4 3 3 0 0 1-3 2 3 3 0 0 1-3-3V3z"/></svg>,
};

function Logo({ size = 40, variant = 'dark' }) {
  const fg = variant === 'dark' ? 'var(--ink)' : 'var(--paper)';
  const accent = 'var(--indigo)';
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none">
      <circle cx="20" cy="20" r="18" stroke={fg} strokeWidth="1.5"/>
      <circle cx="20" cy="20" r="11" stroke={fg} strokeWidth="1.5" opacity="0.5"/>
      <circle cx="20" cy="20" r="5" fill={accent}/>
      <circle cx="20" cy="20" r="1.5" fill="var(--paper-pure)"/>
    </svg>
  );
}

function Wordmark({ size = 24, variant = 'dark' }) {
  const fg = variant === 'dark' ? 'var(--ink)' : 'var(--paper)';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <Logo size={size + 8} variant={variant} />
      <div style={{
        fontFamily: 'var(--font-display)',
        fontSize: size,
        letterSpacing: '-0.02em',
        color: fg,
        lineHeight: 1,
      }}>
        lumen<em style={{ fontStyle: 'italic', color: 'var(--indigo)' }}>.</em>
      </div>
    </div>
  );
}

Object.assign(window, { Icons, Logo, Wordmark });
