/* eslint-disable */
/* =============================================================
   AIS — Components artboards
   ============================================================= */

function ArtButtons() {
  return (
    <div className="ds-artboard">
      <div className="ds-header">
        <h2 className="ds-header__title">Buttons &amp; controls — <em>tactile, quiet.</em></h2>
        <div className="ds-header__meta">02 · Components</div>
      </div>

      <div className="ds-sub">Variants</div>
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 32, alignItems: 'center' }}>
        <button className="btn btn--accent">Begin lesson {React.cloneElement(Icons.arrowRight, { className: 'icon' })}</button>
        <button className="btn btn--primary">Continue</button>
        <button className="btn btn--secondary">Review later</button>
        <button className="btn btn--ghost">Skip</button>
        <button className="btn btn--icon btn--secondary" aria-label="more">{Icons.more}</button>
      </div>

      <div className="ds-sub">Sizes</div>
      <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 32 }}>
        <button className="btn btn--accent btn--sm">Small</button>
        <button className="btn btn--accent">Default</button>
        <button className="btn btn--accent btn--lg">Large</button>
        <button className="btn btn--accent btn--lg btn--pill">Start free trial</button>
      </div>

      <div className="ds-sub">States</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 32 }}>
        {[
          ['Resting', { }],
          ['Hover', { background: 'var(--indigo-deep)' }],
          ['Focus', { boxShadow: 'var(--shadow-focus), 0 2px 0 0 var(--indigo-deep)' }],
          ['Disabled', { opacity: 0.4, cursor: 'not-allowed' }],
        ].map(([label, s]) => (
          <div key={label} style={{ display: 'flex', flexDirection: 'column', gap: 10, alignItems: 'flex-start' }}>
            <button className="btn btn--accent" style={s}>Begin lesson</button>
            <div className="ds-caption">{label}</div>
          </div>
        ))}
      </div>

      <hr className="ds-hr"/>

      <div className="ds-sub">Inputs</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 24, maxWidth: 720 }}>
        <div>
          <label className="label">Email</label>
          <input className="input" placeholder="you@domain.com" defaultValue="sam@lumen.app"/>
        </div>
        <div>
          <label className="label">Target language</label>
          <div style={{ position: 'relative' }}>
            <input className="input" defaultValue="日本語 · Japanese"/>
            <span style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-4)' }}>{Icons.globe}</span>
          </div>
        </div>
        <div>
          <label className="label">Search lessons</label>
          <div style={{ position: 'relative' }}>
            <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-4)' }}>{Icons.search}</span>
            <input className="input" style={{ paddingLeft: 44 }} placeholder="Try &quot;ordering coffee&quot;"/>
          </div>
        </div>
        <div>
          <label className="label">Focused</label>
          <input className="input" defaultValue="Practice greetings" style={{ borderColor: 'var(--indigo)', boxShadow: 'var(--shadow-focus)' }}/>
        </div>
      </div>

      <hr className="ds-hr"/>

      <div className="ds-sub">Chips</div>
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
        <span className="chip"><span className="dot"/>Default</span>
        <span className="chip chip--indigo">{Icons.sparkle}AI tutor</span>
        <span className="chip chip--moss">{Icons.check}Completed · 12</span>
        <span className="chip chip--saffron">{Icons.flame}7 day streak</span>
        <span className="chip chip--coral">{Icons.heart}3 lives left</span>
        <span className="chip chip--ocean">{Icons.mic}Voice ready</span>
        <span className="chip chip--plum">{Icons.avatar}Avatar · new</span>
      </div>
    </div>
  );
}

function ArtCardsAndData() {
  return (
    <div className="ds-artboard">
      <div className="ds-header">
        <h2 className="ds-header__title">Cards &amp; data — <em>the learning unit.</em></h2>
        <div className="ds-header__meta">02 · Components</div>
      </div>

      <div className="ds-sub">Lesson cards · one per mode</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, marginBottom: 32 }}>
        {[
          { hue: 'ocean',   icon: 'mic',        title: 'Voice · Ordering coffee',       sub: '12 min · conversational',       lvl: 'A2' },
          { hue: 'indigo',  icon: 'book',       title: 'Interactive · Prompt design',    sub: '18 min · 6 exercises',           lvl: 'Pro' },
          { hue: 'saffron', icon: 'play',       title: 'Video · The history of LLMs',    sub: '9 min · with captions',          lvl: '101' },
          { hue: 'plum',    icon: 'avatar',     title: 'Avatar · Interview practice',    sub: '20 min · roleplay',              lvl: 'B1' },
          { hue: 'moss',    icon: 'check',      title: 'Quiz · Week 3 review',           sub: '10 questions · mixed',            lvl: '—' },
          { hue: 'coral',   icon: 'headphones', title: 'Audio chat · Morning debate',    sub: '15 min · live transcript',        lvl: 'B2' },
        ].map((c, i) => (
          <div key={i} className="card card--hover" style={{ position: 'relative' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
              <div style={{
                width: 44, height: 44, borderRadius: 'var(--r-3)',
                background: `var(--${c.hue}-soft)`,
                color: `var(--${c.hue}-deep)`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {React.cloneElement(Icons[c.icon], { className: 'icon icon--lg' })}
              </div>
              <span className={`chip chip--${c.hue}`}>{c.lvl}</span>
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, letterSpacing: '-0.01em', marginBottom: 6, lineHeight: 1.2 }}>{c.title}</div>
            <div style={{ fontSize: 13, color: 'var(--text-3)' }}>{c.sub}</div>
          </div>
        ))}
      </div>

      <hr className="ds-hr"/>

      <div className="ds-sub">Progress · multiple treatments</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24, marginBottom: 24 }}>
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>Week 3 · Prompt foundations</span>
            <span className="mono" style={{ fontSize: 12, color: 'var(--text-3)' }}>68%</span>
          </div>
          <div className="progress"><div className="progress__fill" style={{ width: '68%' }}/></div>
        </div>
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>{Icons.flame}&nbsp;Daily streak</span>
            <span className="mono" style={{ fontSize: 12, color: 'var(--saffron-deep)' }}>5 of 7</span>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            {[1,2,3,4,5,6,7].map(i => (
              <div key={i} style={{
                flex: 1, height: 28, borderRadius: 6,
                background: i <= 5 ? 'var(--saffron)' : 'var(--bg-soft)',
                border: i <= 5 ? '1px solid var(--saffron-deep)' : '1px solid var(--border)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 10, fontWeight: 700,
                color: i <= 5 ? 'var(--saffron-deep)' : 'var(--text-4)',
              }}>{['M','T','W','T','F','S','S'][i-1]}</div>
            ))}
          </div>
        </div>
        <div className="card">
          <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 14 }}>Skill tree · Japanese</div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            {[1,2,3,4,5].map(i => (
              <React.Fragment key={i}>
                <div style={{
                  width: 32, height: 32, borderRadius: '50%',
                  background: i <= 3 ? 'var(--moss)' : i === 4 ? 'var(--indigo)' : 'var(--bg-soft)',
                  color: i <= 4 ? '#fff' : 'var(--text-4)',
                  border: i === 4 ? '3px solid var(--indigo-soft)' : 'none',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 12, fontWeight: 700,
                }}>{i <= 3 ? '✓' : i}</div>
                {i < 5 && <div style={{ flex: 1, height: 2, background: i <= 2 ? 'var(--moss)' : 'var(--border)' }}/>}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      <hr className="ds-hr"/>

      <div className="ds-sub">Toast · feedback</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16, maxWidth: 880 }}>
        {[
          { hue: 'moss',    icon: 'check',   title: 'Lesson complete',       body: '+ 40 XP added · 7-day streak saved.' },
          { hue: 'coral',   icon: 'x',       title: 'Connection lost',        body: 'Your answers are saved locally.' },
          { hue: 'ocean',   icon: 'mic',     title: 'Microphone enabled',     body: 'Speak clearly and at a normal pace.' },
          { hue: 'saffron', icon: 'sparkle', title: 'New AI tutor available', body: 'Maya now supports Japanese.' },
        ].map((t, i) => (
          <div key={i} style={{
            display: 'flex', gap: 14, padding: 16,
            background: `var(--${t.hue}-soft)`,
            border: `1px solid var(--${t.hue})`,
            borderRadius: 'var(--r-3)',
          }}>
            <div style={{ color: `var(--${t.hue}-deep)` }}>{React.cloneElement(Icons[t.icon], { className: 'icon icon--lg' })}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 14, color: `var(--${t.hue}-deep)`, marginBottom: 2 }}>{t.title}</div>
              <div style={{ fontSize: 13, color: 'var(--text-2)' }}>{t.body}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { ArtButtons, ArtCardsAndData });
