/* eslint-disable */
/* =============================================================
   AIS — Foundation artboards: Brand, Color, Type, Spacing, Motion,
   Illustration direction, Iconography
   ============================================================= */

/* ---------- BRAND / COVER ---------- */
function ArtCover() {
  return (
    <div className="ds-artboard ds-artboard--flush" style={{
      padding: 72,
      background: 'var(--paper)',
      position: 'relative',
      overflow: 'hidden',
    }}>
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage:
          'radial-gradient(circle at 85% 20%, rgba(79,70,186,0.08), transparent 40%), radial-gradient(circle at 10% 85%, rgba(232,163,58,0.08), transparent 35%)',
        pointerEvents: 'none',
      }}/>
      <div style={{ position: 'relative', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <Wordmark size={28}/>
          <div className="mono" style={{ fontSize: 12, color: 'var(--text-3)', textAlign: 'right', lineHeight: 1.7 }}>
            AIS · DESIGN SYSTEM<br/>
            v1.0 · 2026<br/>
            &mdash; calm &amp; academic
          </div>
        </div>

        <div>
          <div className="eyebrow" style={{ marginBottom: 28 }}>§ Design system</div>
          <h1 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 140,
            lineHeight: 0.95,
            letterSpacing: '-0.04em',
            fontWeight: 300,
            marginBottom: 24,
            maxWidth: 1000,
          }}>
            A library<br/>
            for <em style={{ fontStyle: 'italic', color: 'var(--indigo)' }}>learning —</em><br/>
            in any language.
          </h1>
          <p style={{
            maxWidth: 640,
            fontSize: 20,
            lineHeight: 1.55,
            color: 'var(--text-2)',
            letterSpacing: '-0.005em',
          }}>
            Lumen is a structured, multilingual design system for an AI-first learning
            product. Interactive lessons, voice, quizzes, video, audio chat, avatar —
            all built from one vocabulary.
          </p>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', borderTop: '1px solid var(--border)', paddingTop: 20 }}>
          <div style={{ display: 'flex', gap: 40 }}>
            {[
              ['01', 'Foundations'],
              ['02', 'Components'],
              ['03', 'Surfaces'],
              ['04', 'Motion'],
            ].map(([n, l]) => (
              <div key={n}>
                <div className="mono" style={{ fontSize: 12, color: 'var(--text-4)' }}>{n}</div>
                <div style={{ fontSize: 16, fontWeight: 600, marginTop: 4 }}>{l}</div>
              </div>
            ))}
          </div>
          <div className="mono" style={{ fontSize: 11, color: 'var(--text-4)', letterSpacing: '0.1em' }}>
            EN · ES · FR · 日本語 · 中文 · العربية · हिन्दी
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- COLOR ---------- */
function Swatch({ name, varName, deep, soft, description }) {
  return (
    <div style={{ flex: 1 }}>
      <div style={{
        height: 180,
        borderRadius: 'var(--r-4)',
        background: `var(${varName})`,
        position: 'relative',
        overflow: 'hidden',
        border: '1px solid var(--border)',
      }}>
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 40, background: `var(${soft})` }}/>
        <div style={{ position: 'absolute', top: 12, left: 16, fontSize: 11, fontFamily: 'var(--font-mono)', color: 'rgba(255,255,255,0.85)', letterSpacing: '0.08em' }}>
          {varName}
        </div>
      </div>
      <div style={{ marginTop: 12 }}>
        <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 2 }}>{name}</div>
        <div style={{ fontSize: 12, color: 'var(--text-3)', lineHeight: 1.4 }}>{description}</div>
      </div>
    </div>
  );
}

function NeutralRamp() {
  const stops = ['--ink','--ink-2','--ink-3','--ink-4','--ink-5','--ink-6','--ink-7','--ink-8','--paper-soft','--paper','--paper-pure'];
  return (
    <div style={{ display: 'flex', borderRadius: 'var(--r-3)', overflow: 'hidden', border: '1px solid var(--border)' }}>
      {stops.map(s => (
        <div key={s} style={{ flex: 1, aspectRatio: '1', background: `var(${s})`, display: 'flex', alignItems: 'flex-end', padding: 8 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9, color: s.includes('paper') || s === '--ink-8' || s === '--ink-7' ? 'var(--ink-3)' : 'var(--paper)' }}>
            {s.replace('--','')}
          </span>
        </div>
      ))}
    </div>
  );
}

function ArtColor() {
  const hues = [
    { name: 'Indigo', v: '--indigo', d: '--indigo-deep', s: '--indigo-soft', desc: 'Core AI · primary action' },
    { name: 'Saffron', v: '--saffron', d: '--saffron-deep', s: '--saffron-soft', desc: 'Streaks · rewards · XP' },
    { name: 'Moss', v: '--moss', d: '--moss-deep', s: '--moss-soft', desc: 'Progress · completion' },
    { name: 'Coral', v: '--coral', d: '--coral-deep', s: '--coral-soft', desc: 'Mistakes · live · alert' },
    { name: 'Ocean', v: '--ocean', d: '--ocean-deep', s: '--ocean-soft', desc: 'Voice · audio · listening' },
    { name: 'Plum', v: '--plum', d: '--plum-deep', s: '--plum-soft', desc: 'Avatar · creative · advanced' },
  ];
  return (
    <div className="ds-artboard">
      <div className="ds-header">
        <h2 className="ds-header__title">Color — <em>six hues, one voice.</em></h2>
        <div className="ds-header__meta">01 · Foundations</div>
      </div>

      <div className="ds-sub">Neutrals · warm ink on paper</div>
      <NeutralRamp/>
      <p className="ds-caption" style={{ marginTop: 12, maxWidth: 760 }}>
        An eleven-step warm neutral ramp. Paper (#F7F5F0) is the canvas; Ink (#151411) is a near-black with warmth. Pure white is reserved for elevated surfaces.
      </p>

      <hr className="ds-hr"/>

      <div className="ds-sub">Category palette · each hue maps to a learning mode</div>
      <div style={{ display: 'flex', gap: 20, marginBottom: 32 }}>
        {hues.slice(0, 3).map(h => <Swatch key={h.name} name={h.name} varName={h.v} deep={h.d} soft={h.s} description={h.desc}/>)}
      </div>
      <div style={{ display: 'flex', gap: 20 }}>
        {hues.slice(3).map(h => <Swatch key={h.name} name={h.name} varName={h.v} deep={h.d} soft={h.s} description={h.desc}/>)}
      </div>

      <hr className="ds-hr"/>

      <div className="ds-sub">Semantic mapping</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
        {[
          { k: 'success', label: 'Success', desc: 'Completed, correct', color: 'var(--moss)' },
          { k: 'warning', label: 'Warning', desc: 'Streak at risk', color: 'var(--saffron)' },
          { k: 'danger',  label: 'Danger',  desc: 'Wrong, error',   color: 'var(--coral)' },
          { k: 'info',    label: 'Info',    desc: 'Tip, hint',     color: 'var(--ocean)' },
        ].map(x => (
          <div key={x.k} style={{ border: '1px solid var(--border)', borderRadius: 'var(--r-3)', padding: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
              <span style={{ width: 10, height: 10, borderRadius: '50%', background: x.color }}/>
              <span style={{ fontWeight: 700, fontSize: 14 }}>{x.label}</span>
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-3)' }}>{x.desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- TYPE ---------- */
function ArtType() {
  return (
    <div className="ds-artboard">
      <div className="ds-header">
        <h2 className="ds-header__title">Type — <em>a pair that reads aloud.</em></h2>
        <div className="ds-header__meta">01 · Foundations</div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 48, marginBottom: 40 }}>
        <div>
          <div className="ds-sub">Display — Fraunces</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 120, lineHeight: 1, letterSpacing: '-0.03em', fontWeight: 300 }}>Aa</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, letterSpacing: '-0.01em', marginTop: 16 }}>
            学 · 한 · ع · भ · あ · क
          </div>
          <p className="ds-caption" style={{ marginTop: 16, maxWidth: 380 }}>
            A soft-edged transitional serif. Used at 28&nbsp;px and above for headings, pull-quotes, and brand moments. Weight 300&ndash;500, never bold.
          </p>
        </div>
        <div>
          <div className="ds-sub">Body · UI — DM Sans</div>
          <div style={{ fontFamily: 'var(--font-sans)', fontSize: 120, lineHeight: 1, letterSpacing: '-0.04em', fontWeight: 500 }}>Aa</div>
          <div style={{ fontFamily: 'var(--font-sans)', fontSize: 28, letterSpacing: '-0.02em', fontWeight: 500, marginTop: 16 }}>
            Ññ Øø Åå Ææ
          </div>
          <p className="ds-caption" style={{ marginTop: 16, maxWidth: 380 }}>
            A humanist geometric with soft terminals. Used for body, UI, labels. Weights 400 / 500 / 600 / 700. Rounded but disciplined — never cutesy.
          </p>
        </div>
      </div>

      <hr className="ds-hr"/>

      <div className="ds-sub">Scale</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {[
          [80, 'Display XL', 'display', 300, '-0.04em'],
          [64, 'Display L',  'display', 300, '-0.03em'],
          [48, 'Display M',  'display', 400, '-0.02em'],
          [32, 'Heading 1',  'sans',    700, '-0.02em'],
          [24, 'Heading 2',  'sans',    700, '-0.015em'],
          [20, 'Heading 3',  'sans',    600, '-0.01em'],
          [17, 'Body L',     'sans',    400, '-0.005em'],
          [15, 'Body',       'sans',    400, '-0.005em'],
          [13, 'Caption',    'sans',    500, '0'],
          [12, 'Eyebrow',    'sans',    600, '0.12em'],
        ].map(([size, label, family, weight, tr]) => (
          <div key={label} style={{
            display: 'grid',
            gridTemplateColumns: '90px 160px 1fr 180px',
            alignItems: 'baseline',
            borderBottom: '1px solid var(--border-soft)',
            padding: '10px 0',
            gap: 16,
          }}>
            <span className="mono" style={{ color: 'var(--text-4)', fontSize: 12 }}>{size}/px</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-3)' }}>{label}</span>
            <span style={{
              fontFamily: family === 'display' ? 'var(--font-display)' : 'var(--font-sans)',
              fontSize: size,
              fontWeight: weight,
              letterSpacing: tr,
              lineHeight: size > 40 ? 0.95 : 1.2,
              textTransform: label === 'Eyebrow' ? 'uppercase' : 'none',
            }}>
              {label === 'Eyebrow' ? 'The listening curriculum' : 'A quiet kind of intelligence.'}
            </span>
            <span className="mono" style={{ color: 'var(--text-4)', fontSize: 11 }}>
              {family === 'display' ? 'Fraunces' : 'DM Sans'} · {weight}
            </span>
          </div>
        ))}
      </div>

      <hr className="ds-hr"/>

      <div className="ds-sub">Multilingual stack — Noto fallback</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {[
          ['English',    'A quiet kind of intelligence.'],
          ['Español',    'Una inteligencia que escucha.'],
          ['Français',   'Une intelligence qui écoute.'],
          ['日本語',      '静かに、深く学ぶ。'],
          ['中文',        '安静的智能，用心聆听。'],
          ['العربية',     'ذكاءٌ يُصغي بهدوء.'],
        ].map(([lang, text]) => (
          <div key={lang} style={{ border: '1px solid var(--border)', borderRadius: 'var(--r-3)', padding: 16 }}>
            <div className="mono" style={{ fontSize: 10, color: 'var(--text-4)', letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 8 }}>{lang}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, letterSpacing: '-0.01em' }} dir={lang === 'العربية' ? 'rtl' : 'ltr'}>{text}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- SPACING / RADII / SHADOWS ---------- */
function ArtSpacing() {
  const spaces = [
    ['--sp-1', 4], ['--sp-2', 8], ['--sp-3', 12], ['--sp-4', 16],
    ['--sp-5', 20], ['--sp-6', 24], ['--sp-8', 32], ['--sp-10', 40],
    ['--sp-12', 48], ['--sp-16', 64], ['--sp-20', 80],
  ];
  const radii = [
    ['--r-1', 4],  ['--r-2', 8],  ['--r-3', 12],
    ['--r-4', 16], ['--r-5', 20], ['--r-6', 24],
    ['--r-7', 32], ['--r-pill', 999],
  ];
  return (
    <div className="ds-artboard">
      <div className="ds-header">
        <h2 className="ds-header__title">Space &amp; form — <em>a calm grid.</em></h2>
        <div className="ds-header__meta">01 · Foundations</div>
      </div>

      <div className="ds-sub">Spacing · 4&nbsp;pt base</div>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 24, marginBottom: 12 }}>
        {spaces.map(([name, px]) => (
          <div key={name} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{ width: px, height: px, background: 'var(--indigo)', borderRadius: 2 }}/>
            <div className="mono" style={{ fontSize: 10, color: 'var(--text-4)', marginTop: 8 }}>{px}</div>
            <div className="mono" style={{ fontSize: 9, color: 'var(--text-4)' }}>{name.replace('--','')}</div>
          </div>
        ))}
      </div>
      <p className="ds-caption" style={{ maxWidth: 760 }}>
        Component padding defaults to 16–24&nbsp;px; cards to 24&nbsp;px; section rhythm to 64–96&nbsp;px on desktop. Mobile cuts those by ~33%.
      </p>

      <hr className="ds-hr"/>

      <div className="ds-sub">Radius · friendly without being cute</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 16 }}>
        {radii.map(([name, px]) => (
          <div key={name} style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 8 }}>
            <div style={{
              width: '100%',
              aspectRatio: '1',
              background: 'var(--indigo-soft)',
              border: '1px solid var(--indigo)',
              borderRadius: `var(${name})`,
            }}/>
            <div className="mono" style={{ fontSize: 10, color: 'var(--text-4)' }}>{name.replace('--','')} · {px === 999 ? 'pill' : `${px}px`}</div>
          </div>
        ))}
      </div>

      <hr className="ds-hr"/>

      <div className="ds-sub">Elevation · four steps, plus focus</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 20, background: 'var(--bg-soft)', padding: 32, borderRadius: 'var(--r-4)' }}>
        {[
          ['shadow-1', 'Resting card'],
          ['shadow-2', 'Hover'],
          ['shadow-3', 'Popover / menu'],
          ['shadow-4', 'Modal'],
          ['shadow-focus', 'Focus ring'],
        ].map(([s, label]) => (
          <div key={s} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 120, height: 80,
              background: 'var(--surface)',
              borderRadius: 'var(--r-3)',
              boxShadow: `var(--${s})`,
              border: s === 'shadow-focus' ? '1px solid var(--border)' : '1px solid var(--border-soft)',
            }}/>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{label}</div>
            <div className="mono" style={{ fontSize: 10, color: 'var(--text-4)' }}>{s}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- MOTION ---------- */
function ArtMotion() {
  const [tick, setTick] = React.useState(0);
  React.useEffect(() => {
    const i = setInterval(() => setTick(t => t + 1), 2600);
    return () => clearInterval(i);
  }, []);
  const curves = [
    ['standard',  'cubic-bezier(0.2, 0, 0, 1)',    'Default UI motion'],
    ['emphasize', 'cubic-bezier(0.3, 0, 0, 1)',    'Major enters & exits'],
    ['decel',     'cubic-bezier(0, 0, 0.2, 1)',    'Entering elements'],
    ['accel',     'cubic-bezier(0.4, 0, 1, 1)',    'Leaving elements'],
    ['spring',    'cubic-bezier(0.34, 1.56, 0.64, 1)', 'Success · celebration'],
  ];
  const durations = [
    ['instant', 80,   'Tap feedback'],
    ['fast',    160,  'Hover · small state'],
    ['base',    240,  'Default transition'],
    ['slow',    400,  'Sheet · dialog'],
    ['slower',  640,  'Onboarding · reward'],
  ];
  return (
    <div className="ds-artboard">
      <div className="ds-header">
        <h2 className="ds-header__title">Motion — <em>slow and graceful.</em></h2>
        <div className="ds-header__meta">04 · Foundations</div>
      </div>

      <div className="ds-sub">Easing curves</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 20, marginBottom: 24 }}>
        {curves.map(([name, cb, desc]) => (
          <div key={name} style={{ border: '1px solid var(--border)', borderRadius: 'var(--r-3)', padding: 20 }}>
            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 6 }}>{name}</div>
            <div className="mono" style={{ fontSize: 10, color: 'var(--text-4)', marginBottom: 12, wordBreak: 'break-all' }}>{cb}</div>
            <div style={{ position: 'relative', height: 40, background: 'var(--bg-soft)', borderRadius: 'var(--r-pill)', overflow: 'hidden' }}>
              <div key={tick} style={{
                position: 'absolute',
                top: 8, left: 8,
                width: 24, height: 24,
                borderRadius: '50%',
                background: 'var(--indigo)',
                animation: `moveRight 1800ms ${cb} forwards`,
              }}/>
            </div>
            <div className="ds-caption" style={{ marginTop: 10 }}>{desc}</div>
          </div>
        ))}
      </div>

      <style>{`@keyframes moveRight { from { transform: translateX(0); } to { transform: translateX(calc(100% - 40px)); } }`}</style>

      <hr className="ds-hr"/>

      <div className="ds-sub">Duration scale</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 16, marginBottom: 32 }}>
        {durations.map(([name, ms, desc]) => (
          <div key={name} style={{ border: '1px solid var(--border)', borderRadius: 'var(--r-3)', padding: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
              <span style={{ fontWeight: 700, fontSize: 14 }}>{name}</span>
              <span className="mono" style={{ fontSize: 11, color: 'var(--text-3)' }}>{ms}ms</span>
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-3)' }}>{desc}</div>
          </div>
        ))}
      </div>

      <div className="ds-sub">Signature transitions</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
        <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--r-3)', padding: 20, background: 'var(--surface)' }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 10 }}>Correct answer</div>
          <div style={{
            height: 60, background: 'var(--moss-soft)', color: 'var(--moss-deep)',
            borderRadius: 'var(--r-3)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 700, animation: 'popIn 640ms cubic-bezier(0.34, 1.56, 0.64, 1) infinite',
          }}>
            ✓ Correct
          </div>
          <div className="ds-caption" style={{ marginTop: 8 }}>scale 0.6 → 1 on <span className="ds-code">spring</span>, 640ms</div>
        </div>
        <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--r-3)', padding: 20, background: 'var(--surface)' }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 10 }}>Wrong answer</div>
          <div style={{
            height: 60, background: 'var(--coral-soft)', color: 'var(--coral-deep)',
            borderRadius: 'var(--r-3)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 700, animation: 'shake 400ms cubic-bezier(0.4, 0, 1, 1) infinite',
          }}>
            ✕ Try again
          </div>
          <div className="ds-caption" style={{ marginTop: 8 }}>translateX ±6px · 3 cycles · <span className="ds-code">accel</span></div>
        </div>
        <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--r-3)', padding: 20, background: 'var(--surface)' }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 10 }}>Listening pulse</div>
          <div style={{
            height: 60, display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: 'var(--ocean-soft)', borderRadius: 'var(--r-3)',
          }}>
            <div style={{
              width: 36, height: 36, borderRadius: '50%',
              background: 'var(--ocean)',
              animation: 'pulse 1600ms cubic-bezier(0.2, 0, 0, 1) infinite',
            }}/>
          </div>
          <div className="ds-caption" style={{ marginTop: 8 }}>scale 1 → 1.25 · opacity 1 → 0.7 · loop</div>
        </div>
      </div>

      <style>{`
        @keyframes popIn { 0% { transform: scale(0.6); opacity: 0; } 60% { transform: scale(1.05); opacity: 1; } 100% { transform: scale(1); opacity: 1; } }
        @keyframes shake { 0%, 100% { transform: translateX(0); } 25% { transform: translateX(-6px); } 75% { transform: translateX(6px); } }
        @keyframes pulse { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.25); opacity: 0.7; } }
      `}</style>
    </div>
  );
}

/* ---------- ICONOGRAPHY ---------- */
function ArtIcons() {
  const icons = [
    ['home', 'Home'], ['book', 'Lesson'], ['mic', 'Voice'], ['play', 'Video'],
    ['chat', 'Chat'], ['avatar', 'Avatar'], ['globe', 'Language'], ['search', 'Search'],
    ['flame', 'Streak'], ['star', 'XP'], ['heart', 'Lives'], ['trophy', 'Reward'],
    ['sparkle', 'AI'], ['brain', 'Practice'], ['headphones', 'Audio'], ['wave', 'Waveform'],
    ['bolt', 'Power'], ['check', 'Correct'], ['x', 'Incorrect'], ['clock', 'Time'],
    ['lock', 'Locked'], ['eye', 'Preview'], ['settings', 'Settings'], ['plus', 'Add'],
  ];
  return (
    <div className="ds-artboard">
      <div className="ds-header">
        <h2 className="ds-header__title">Icons — <em>1.5&nbsp;px line, 24&nbsp;px canvas.</em></h2>
        <div className="ds-header__meta">01 · Foundations</div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(8, 1fr)', gap: 4, border: '1px solid var(--border)', borderRadius: 'var(--r-4)', padding: 4, background: 'var(--surface)' }}>
        {icons.map(([key, label]) => (
          <div key={key} style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12,
            padding: 20, borderRadius: 'var(--r-2)',
          }}>
            <div style={{ width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {React.cloneElement(Icons[key], { className: 'icon icon--lg' })}
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', fontWeight: 500 }}>{label}</div>
          </div>
        ))}
      </div>

      <hr className="ds-hr"/>

      <div className="ds-sub">Usage · size · color</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20 }}>
        {[
          [16, 'Inline · body'],
          [20, 'UI · default'],
          [28, 'Nav · action'],
          [40, 'Feature · hero'],
        ].map(([size, label]) => (
          <div key={size} style={{ border: '1px solid var(--border)', borderRadius: 'var(--r-3)', padding: 20, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
            <div style={{ width: size, height: size, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--indigo)' }}>
              {React.cloneElement(Icons.sparkle, { style: { width: size, height: size, strokeWidth: size >= 28 ? 1.4 : 1.75 }, className: '' })}
            </div>
            <div style={{ fontSize: 13, fontWeight: 600 }}>{size}px</div>
            <div className="ds-caption">{label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- ILLUSTRATION ---------- */
function ArtIllustration() {
  return (
    <div className="ds-artboard">
      <div className="ds-header">
        <h2 className="ds-header__title">Illustration — <em>geometric, printed, warm.</em></h2>
        <div className="ds-header__meta">01 · Foundations</div>
      </div>

      <div className="ds-sub">Aesthetic · three-layer minimal geometry</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 24, marginBottom: 24 }}>
        {/* Illus 1 — The Listener */}
        <div style={{ aspectRatio: '4/3', background: 'var(--ocean-soft)', borderRadius: 'var(--r-4)', padding: 24, position: 'relative', overflow: 'hidden' }}>
          <svg viewBox="0 0 200 140" style={{ width: '100%', height: '100%' }}>
            <circle cx="100" cy="90" r="50" fill="var(--paper)"/>
            <circle cx="100" cy="90" r="50" fill="none" stroke="var(--ocean-deep)" strokeWidth="1.5"/>
            {[20, 32, 44].map((r, i) => (
              <circle key={i} cx="100" cy="90" r={r} fill="none" stroke="var(--ocean)" strokeWidth="1.5" opacity={0.8 - i*0.2}/>
            ))}
            <circle cx="100" cy="90" r="8" fill="var(--ocean-deep)"/>
            <path d="M 40 40 Q 100 20 160 40" stroke="var(--ocean-deep)" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
            <circle cx="40" cy="40" r="3" fill="var(--saffron)"/>
            <circle cx="160" cy="40" r="3" fill="var(--saffron)"/>
          </svg>
          <div style={{ position: 'absolute', bottom: 16, left: 24, fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 14, color: 'var(--ocean-deep)' }}>The listener</div>
        </div>
        {/* Illus 2 — The Ladder */}
        <div style={{ aspectRatio: '4/3', background: 'var(--saffron-soft)', borderRadius: 'var(--r-4)', padding: 24, position: 'relative', overflow: 'hidden' }}>
          <svg viewBox="0 0 200 140" style={{ width: '100%', height: '100%' }}>
            {[110, 85, 60, 35].map((y, i) => (
              <rect key={i} x={40 + i*12} y={y} width="100" height={120-y} fill={i === 3 ? 'var(--saffron)' : 'var(--paper)'} stroke="var(--saffron-deep)" strokeWidth="1.5"/>
            ))}
            <circle cx="140" cy="24" r="8" fill="var(--saffron-deep)"/>
            <path d="M 148 18 L 165 8" stroke="var(--saffron-deep)" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
          <div style={{ position: 'absolute', bottom: 16, left: 24, fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 14, color: 'var(--saffron-deep)' }}>The path</div>
        </div>
        {/* Illus 3 — The Mirror */}
        <div style={{ aspectRatio: '4/3', background: 'var(--plum-soft)', borderRadius: 'var(--r-4)', padding: 24, position: 'relative', overflow: 'hidden' }}>
          <svg viewBox="0 0 200 140" style={{ width: '100%', height: '100%' }}>
            <ellipse cx="100" cy="70" rx="60" ry="50" fill="var(--paper)" stroke="var(--plum-deep)" strokeWidth="1.5"/>
            <circle cx="85" cy="60" r="4" fill="var(--plum-deep)"/>
            <circle cx="115" cy="60" r="4" fill="var(--plum-deep)"/>
            <path d="M 85 85 Q 100 95 115 85" stroke="var(--plum-deep)" strokeWidth="1.5" fill="none" strokeLinecap="round"/>
            <circle cx="100" cy="70" r="68" fill="none" stroke="var(--plum)" strokeWidth="1.5" strokeDasharray="3 4"/>
          </svg>
          <div style={{ position: 'absolute', bottom: 16, left: 24, fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 14, color: 'var(--plum-deep)' }}>The mirror</div>
        </div>
      </div>

      <p className="ds-caption" style={{ maxWidth: 760, marginBottom: 32 }}>
        All product illustrations share a single vocabulary: paper-colored flats, 1.5&nbsp;px strokes in the hue's deep tone, one saffron accent dot, concentric rings for AI presence. Think <em>New Yorker</em> spot illustrations, not Memphis, not 3D. No gradients. No glows.
      </p>

      <hr className="ds-hr"/>

      <div className="ds-sub">Photography direction</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
        {[
          ['Paper', 'var(--paper)', 'Hands, notebooks, warm daylight'],
          ['Patina', 'var(--saffron-soft)', 'Brass, linen, worn wood'],
          ['Dusk', 'var(--indigo-soft)', 'Low-key study, reading light'],
          ['Field', 'var(--moss-soft)', 'Outdoor learning, conversation'],
        ].map(([name, bg, desc]) => (
          <div key={name}>
            <div style={{
              aspectRatio: '4/5',
              background: bg,
              borderRadius: 'var(--r-3)',
              border: '1px solid var(--border)',
              position: 'relative',
              overflow: 'hidden',
            }}>
              <div style={{
                position: 'absolute', inset: 0,
                background: 'radial-gradient(circle at 30% 20%, rgba(255,255,255,0.6), transparent 60%)',
              }}/>
              <div style={{ position: 'absolute', bottom: 12, left: 12, fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 14, color: 'var(--ink-3)' }}>— {name.toLowerCase()}</div>
            </div>
            <div className="ds-caption" style={{ marginTop: 8 }}>{desc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { ArtCover, ArtColor, ArtType, ArtSpacing, ArtMotion, ArtIcons, ArtIllustration });
