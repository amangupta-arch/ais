/* eslint-disable */
/* AIS — extra surfaces: Leaderboard, Settings, and Dark-mode showcase */

function ScreenLeaderboard() {
  const people = [
    { name: 'Noor A.',    xp: 4820, f: 'AR', self: false },
    { name: 'Kenji T.',   xp: 4610, f: 'JP', self: false },
    { name: 'Sam K.',     xp: 4320, f: 'US', self: true  },
    { name: 'Priya R.',   xp: 4100, f: 'IN', self: false },
    { name: 'Lucía M.',   xp: 3980, f: 'ES', self: false },
    { name: 'Théo D.',    xp: 3750, f: 'FR', self: false },
    { name: 'Chen W.',    xp: 3600, f: 'CN', self: false },
  ];
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--paper)' }}>
      <div style={{ padding: '20px 20px 8px' }}>
        <div className="eyebrow" style={{ marginBottom: 4 }}>Cohort · November</div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: '-0.02em' }}>
          The <em style={{ fontStyle: 'italic', color: 'var(--saffron-deep)' }}>Library.</em>
        </div>
      </div>

      <div style={{ padding: '0 20px', display: 'flex', gap: 6, marginBottom: 12 }}>
        {['Week','Month','All time'].map((t, i) => (
          <div key={t} style={{
            padding: '6px 12px', borderRadius: 999, fontSize: 12, fontWeight: 600,
            background: i === 1 ? 'var(--ink)' : 'var(--surface)',
            color:      i === 1 ? 'var(--paper)' : 'var(--text-3)',
            border: i === 1 ? 'none' : '1px solid var(--border)',
          }}>{t}</div>
        ))}
      </div>

      <div style={{ padding: '0 20px', flex: 1, overflow: 'hidden' }}>
        {people.map((p, i) => (
          <div key={p.name} style={{
            display: 'flex', alignItems: 'center', gap: 12, padding: '12px 12px',
            borderRadius: 'var(--r-3)', marginBottom: 4,
            background: p.self ? 'var(--indigo-soft)' : 'transparent',
            border: p.self ? '1.5px solid var(--indigo)' : '1px solid transparent',
          }}>
            <div style={{
              width: 24, fontFamily: 'var(--font-display)', fontSize: 18,
              color: i === 0 ? 'var(--saffron-deep)' : i === 1 ? 'var(--text-3)' : i === 2 ? 'var(--coral-deep)' : 'var(--text-4)',
              fontStyle: i < 3 ? 'italic' : 'normal',
            }}>{i + 1}</div>
            <div className="avatar" style={{ width: 32, height: 32, fontSize: 11, background: `var(--${['saffron','ocean','indigo','plum','moss','coral','ink'][i]}-soft)` }}>
              {p.name.charAt(0)}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600 }}>{p.name} {p.self && <span style={{ fontSize: 10, color: 'var(--indigo-deep)', fontWeight: 700 }}>· you</span>}</div>
              <div style={{ fontSize: 10, color: 'var(--text-4)', letterSpacing: '0.05em' }}>{p.f}</div>
            </div>
            <div className="mono" style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-2)' }}>{p.xp.toLocaleString()}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ScreenSettings() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--paper)' }}>
      <div style={{ padding: '20px 20px 16px' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: '-0.02em' }}>Settings</div>
      </div>

      <div style={{ padding: '0 20px', flex: 1, overflow: 'hidden' }}>
        <div style={{ background: 'var(--surface)', borderRadius: 'var(--r-4)', border: '1px solid var(--border)', marginBottom: 16 }}>
          {[
            { icon: 'globe', l: 'Interface language', v: 'English' },
            { icon: 'book',  l: 'Learning language', v: '日本語' },
            { icon: 'mic',   l: 'Voice · Maya',       v: 'Warm' },
          ].map((r, i, arr) => (
            <div key={i} style={{
              padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12,
              borderBottom: i < arr.length - 1 ? '1px solid var(--border-soft)' : 'none',
            }}>
              <div style={{ color: 'var(--text-3)' }}>{Icons[r.icon]}</div>
              <div style={{ flex: 1, fontSize: 13, fontWeight: 600 }}>{r.l}</div>
              <div style={{ fontSize: 13, color: 'var(--text-3)' }}>{r.v}</div>
              <span style={{ color: 'var(--text-4)' }}>{Icons.arrowRight}</span>
            </div>
          ))}
        </div>

        <div style={{ background: 'var(--surface)', borderRadius: 'var(--r-4)', border: '1px solid var(--border)', marginBottom: 16 }}>
          {[
            { icon: 'sparkle', l: 'AI tutor style',      v: 'Encouraging' },
            { icon: 'clock',   l: 'Daily reminder',      v: '08:30' },
            { icon: 'heart',   l: 'Rest day',            v: 'Sunday' },
          ].map((r, i, arr) => (
            <div key={i} style={{
              padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12,
              borderBottom: i < arr.length - 1 ? '1px solid var(--border-soft)' : 'none',
            }}>
              <div style={{ color: 'var(--text-3)' }}>{Icons[r.icon]}</div>
              <div style={{ flex: 1, fontSize: 13, fontWeight: 600 }}>{r.l}</div>
              <div style={{ fontSize: 13, color: 'var(--text-3)' }}>{r.v}</div>
              <span style={{ color: 'var(--text-4)' }}>{Icons.arrowRight}</span>
            </div>
          ))}
        </div>

        <div style={{ padding: '14px 16px', background: 'var(--surface)', borderRadius: 'var(--r-4)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ color: 'var(--text-3)' }}>{Icons.eye}</div>
          <div style={{ flex: 1, fontSize: 13, fontWeight: 600 }}>Dark mode</div>
          <div style={{
            width: 42, height: 24, borderRadius: 999, background: 'var(--indigo)',
            position: 'relative', padding: 2,
          }}>
            <div style={{ width: 20, height: 20, borderRadius: '50%', background: '#fff', marginLeft: 18 }}/>
          </div>
        </div>
      </div>
    </div>
  );
}

/* Dark-mode showcase — four mini screens in one artboard */
function ArtDarkMode() {
  return (
    <div className="ds-artboard ds-artboard--ink" data-theme="dark" style={{ background: 'var(--paper)' }}>
      <div className="ds-header" style={{ borderColor: 'var(--border)' }}>
        <h2 className="ds-header__title" style={{ color: 'var(--text)' }}>Dark — <em>the same library, after dusk.</em></h2>
        <div className="ds-header__meta" style={{ color: 'var(--text-3)' }}>03 · Theme</div>
      </div>

      <p className="ds-caption" style={{ maxWidth: 720, marginBottom: 32, color: 'var(--text-3)' }}>
        Dark mode inverts ink and paper but preserves the warm bias. Hue <em>glow</em> tokens replace base hues for legibility. Soft fills drop to ~15% luminance of their base hue.
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20 }}>
        <div className="card" style={{ padding: 20 }}>
          <div className="chip chip--indigo" style={{ marginBottom: 14 }}>{Icons.sparkle}AI tutor</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, marginBottom: 8 }}>Today's session</div>
          <p style={{ fontSize: 13, color: 'var(--text-3)' }}>Voice agents that listen well — 12 min, conversational.</p>
        </div>
        <div className="card" style={{ padding: 20 }}>
          <div style={{ color: 'var(--saffron-glow)' }}>{Icons.flame}</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 32, color: 'var(--saffron-glow)', lineHeight: 1, margin: '8px 0 2px' }}>12</div>
          <div style={{ fontSize: 11, color: 'var(--text-3)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Day streak</div>
        </div>
        <div className="card" style={{ padding: 20 }}>
          <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 10 }}>Week 3 · 68%</div>
          <div className="progress"><div className="progress__fill" style={{ width: '68%' }}/></div>
          <div style={{ display: 'flex', gap: 4, marginTop: 12 }}>
            {[1,2,3,4,5].map(i => (
              <div key={i} style={{
                flex: 1, height: 6, borderRadius: 3,
                background: i <= 3 ? 'var(--moss-glow)' : 'var(--ink-7)',
              }}/>
            ))}
          </div>
        </div>
        <div className="card" style={{ padding: 20, background: 'var(--indigo)', color: '#fff', borderColor: 'transparent' }}>
          <div style={{ fontSize: 11, letterSpacing: '0.1em', textTransform: 'uppercase', opacity: 0.8, marginBottom: 8 }}>Continue</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, lineHeight: 1.1, marginBottom: 16 }}>Voice · Ordering coffee</div>
          <button className="btn btn--secondary btn--sm" style={{ background: 'rgba(255,255,255,0.15)', color: '#fff', border: 'none' }}>Resume {Icons.arrowRight}</button>
        </div>
      </div>

      <div style={{ marginTop: 32, display: 'flex', gap: 16 }}>
        <button className="btn btn--accent">Begin lesson {Icons.arrowRight}</button>
        <button className="btn btn--secondary">Review</button>
        <button className="btn btn--ghost">Skip</button>
        <div style={{ flex: 1 }}/>
        <span className="chip chip--moss">{Icons.check}+ 40 XP</span>
        <span className="chip chip--coral">{Icons.heart}3 lives</span>
        <span className="chip chip--ocean">{Icons.mic}Voice ready</span>
      </div>
    </div>
  );
}

Object.assign(window, { ScreenLeaderboard, ScreenSettings, ArtDarkMode });
