/* eslint-disable */
/* =============================================================
   AIS — Learning surface mockups (phone frames)
   ============================================================= */

function PhoneFrame({ children, label, hue = 'indigo' }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
      <div className="phone">
        <div className="phone__notch"/>
        <div className="phone__status">
          <span>9:41</span>
          <span style={{ display: 'flex', gap: 4, alignItems: 'center', fontSize: 11 }}>●●● ▲ ■</span>
        </div>
        <div className="phone__inner">{children}</div>
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 18, color: `var(--${hue}-deep)`, letterSpacing: '-0.01em' }}>
        — {label}
      </div>
    </div>
  );
}

/* ---------- ONBOARDING ---------- */
function ScreenOnboarding() {
  return (
    <div style={{ padding: '32px 24px', display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--paper)' }}>
      <Wordmark size={18}/>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 32 }}>
        <div>
          <div className="eyebrow" style={{ marginBottom: 12, fontSize: 10 }}>Step 1 of 4</div>
          <h1 style={{ fontSize: 30, letterSpacing: '-0.03em', lineHeight: 1.05, fontWeight: 400, marginBottom: 12 }}>
            What do<br/>
            you want to<br/>
            <em style={{ fontStyle: 'italic', color: 'var(--indigo)' }}>learn?</em>
          </h1>
          <p style={{ fontSize: 14, color: 'var(--text-3)', maxWidth: 280 }}>
            Pick one to begin. You can add more any time.
          </p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          {[
            { hue: 'indigo',  icon: 'sparkle', label: 'Prompt craft' },
            { hue: 'ocean',   icon: 'mic',     label: 'Voice AI' },
            { hue: 'plum',    icon: 'avatar',  label: 'Agents' },
            { hue: 'saffron', icon: 'brain',   label: 'Fundamentals' },
            { hue: 'moss',    icon: 'book',    label: 'Safety' },
            { hue: 'coral',   icon: 'bolt',    label: 'Fine-tuning' },
          ].map((c, i) => (
            <div key={i} style={{
              padding: 16,
              borderRadius: 'var(--r-3)',
              background: i === 0 ? `var(--${c.hue}-soft)` : 'var(--surface)',
              border: i === 0 ? `1.5px solid var(--${c.hue})` : '1px solid var(--border)',
            }}>
              <div style={{ color: `var(--${c.hue}-deep)`, marginBottom: 10 }}>{React.cloneElement(Icons[c.icon], { className: 'icon icon--lg' })}</div>
              <div style={{ fontSize: 13, fontWeight: 600 }}>{c.label}</div>
            </div>
          ))}
        </div>
      </div>
      <button className="btn btn--accent btn--lg" style={{ width: '100%' }}>Continue</button>
    </div>
  );
}

/* ---------- HOME ---------- */
function ScreenHome() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--paper)' }}>
      <div style={{ padding: '20px 20px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 11, color: 'var(--text-3)', fontWeight: 500, letterSpacing: '0.05em', textTransform: 'uppercase' }}>Thursday · Day 12</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.02em', marginTop: 2 }}>
            Good morning, <em style={{ fontStyle: 'italic', color: 'var(--indigo)' }}>Sam.</em>
          </div>
        </div>
        <div className="avatar" style={{ width: 36, height: 36, fontSize: 12 }}>SK</div>
      </div>

      <div style={{ padding: '0 20px', display: 'flex', gap: 8, marginBottom: 16 }}>
        <div style={{ flex: 1, padding: 10, borderRadius: 'var(--r-3)', background: 'var(--saffron-soft)', display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
          <div style={{ color: 'var(--saffron-deep)' }}>{Icons.flame}</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, color: 'var(--saffron-deep)', lineHeight: 1 }}>12</div>
          <div style={{ fontSize: 10, color: 'var(--saffron-deep)', fontWeight: 600 }}>Day streak</div>
        </div>
        <div style={{ flex: 1, padding: 10, borderRadius: 'var(--r-3)', background: 'var(--indigo-soft)', display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
          <div style={{ color: 'var(--indigo-deep)' }}>{Icons.star}</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, color: 'var(--indigo-deep)', lineHeight: 1 }}>2,140</div>
          <div style={{ fontSize: 10, color: 'var(--indigo-deep)', fontWeight: 600 }}>Total XP</div>
        </div>
        <div style={{ flex: 1, padding: 10, borderRadius: 'var(--r-3)', background: 'var(--moss-soft)', display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
          <div style={{ color: 'var(--moss-deep)' }}>{Icons.check}</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, color: 'var(--moss-deep)', lineHeight: 1 }}>37</div>
          <div style={{ fontSize: 10, color: 'var(--moss-deep)', fontWeight: 600 }}>Lessons</div>
        </div>
      </div>

      <div style={{ padding: '0 20px', flex: 1, overflow: 'hidden' }}>
        <div className="ds-sub" style={{ fontSize: 10, marginBottom: 10 }}>Today's path</div>
        <div style={{
          padding: 16, borderRadius: 'var(--r-4)',
          background: 'linear-gradient(135deg, var(--indigo) 0%, var(--plum) 100%)',
          color: '#fff', marginBottom: 12, position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', opacity: 0.75, marginBottom: 8 }}>Continue · lesson 4</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, lineHeight: 1.1, marginBottom: 12 }}>
            Voice agents<br/>that listen well.
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: 11, opacity: 0.85 }}>12 min · Voice lesson</div>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#fff', color: 'var(--indigo-deep)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {Icons.arrowRight}
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
            { hue: 'ocean',   icon: 'mic',    t: 'Voice practice', m: '8 min', locked: false },
            { hue: 'saffron', icon: 'brain',  t: 'Quiz · Week 2',  m: '5 min', locked: false },
            { hue: 'plum',    icon: 'avatar', t: 'Meet Maya',      m: 'New',   locked: true  },
          ].map((l, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: 12,
              borderRadius: 'var(--r-3)', background: 'var(--surface)', border: '1px solid var(--border)',
              opacity: l.locked ? 0.55 : 1,
            }}>
              <div style={{ width: 36, height: 36, borderRadius: 'var(--r-2)', background: `var(--${l.hue}-soft)`, color: `var(--${l.hue}-deep)`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {Icons[l.icon]}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{l.t}</div>
                <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{l.m}</div>
              </div>
              {l.locked ? Icons.lock : Icons.arrowRight}
            </div>
          ))}
        </div>
      </div>

      {/* Tab bar */}
      <div style={{ padding: '10px 20px 16px', borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'space-around', background: 'var(--surface)' }}>
        {[
          ['home', 'Home', true],
          ['book', 'Learn', false],
          ['chat', 'Chat', false],
          ['trophy', 'Goals', false],
          ['avatar', 'You', false],
        ].map(([k, l, a]) => (
          <div key={k} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, color: a ? 'var(--indigo)' : 'var(--text-4)' }}>
            {Icons[k]}
            <div style={{ fontSize: 9, fontWeight: 600 }}>{l}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- INTERACTIVE LESSON ---------- */
function ScreenLesson() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--paper)' }}>
      <div style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ color: 'var(--text-2)' }}>{Icons.x}</div>
        <div className="progress" style={{ flex: 1 }}><div className="progress__fill" style={{ width: '60%' }}/></div>
        <span className="chip chip--coral" style={{ padding: '4px 10px', fontSize: 11 }}>{Icons.heart}3</span>
      </div>

      <div style={{ padding: '16px 20px', flex: 1, display: 'flex', flexDirection: 'column' }}>
        <div className="eyebrow" style={{ marginBottom: 10 }}>Fill in the gap</div>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.02em', lineHeight: 1.15, marginBottom: 24 }}>
          A good prompt always <em style={{ fontStyle: 'italic', color: 'var(--indigo)' }}>___</em> the task, the audience, and the format.
        </h2>

        <div style={{ padding: 16, borderRadius: 'var(--r-3)', background: 'var(--indigo-soft)', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--indigo)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{Icons.sparkle}</div>
          <div style={{ fontSize: 13, color: 'var(--indigo-deep)' }}>
            <strong>Tip:</strong> think about what the AI needs to know, not what you already know.
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 'auto' }}>
          {[
            { t: 'specifies', selected: true },
            { t: 'hides' },
            { t: 'skips' },
            { t: 'confuses' },
          ].map((o, i) => (
            <div key={i} style={{
              padding: '16px 14px',
              borderRadius: 'var(--r-3)',
              border: o.selected ? '2px solid var(--indigo)' : '1px solid var(--border)',
              background: o.selected ? 'var(--indigo-soft)' : 'var(--surface)',
              fontWeight: 600, fontSize: 15,
              color: o.selected ? 'var(--indigo-deep)' : 'var(--text)',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              boxShadow: 'var(--shadow-key)',
            }}>
              <span>{o.t}</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-4)' }}>{i + 1}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={{ padding: '12px 20px 18px', borderTop: '1px solid var(--border)', background: 'var(--moss-soft)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, color: 'var(--moss-deep)' }}>
          {Icons.check}<span style={{ fontWeight: 700, fontSize: 14 }}>Nice one.</span>
        </div>
        <button className="btn btn--accent" style={{ width: '100%', background: 'var(--moss)', boxShadow: '0 2px 0 0 var(--moss-deep)' }}>Continue</button>
      </div>
    </div>
  );
}

/* ---------- VOICE LESSON ---------- */
function ScreenVoice() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--ocean-deep)', color: 'var(--paper)' }}>
      <div style={{ padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ color: 'var(--paper)' }}>{Icons.arrowLeft}</span>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', opacity: 0.7 }}>Voice · roleplay</div>
          <div style={{ fontSize: 14, fontWeight: 600 }}>Ordering coffee</div>
        </div>
        <span style={{ color: 'var(--paper)' }}>{Icons.more}</span>
      </div>

      <div style={{ flex: 1, padding: '20px', display: 'flex', flexDirection: 'column' }}>
        <div style={{
          padding: '14px 16px', borderRadius: 'var(--r-4)', background: 'rgba(255,255,255,0.08)',
          marginBottom: 8, alignSelf: 'flex-start', maxWidth: '85%',
        }}>
          <div style={{ fontSize: 10, opacity: 0.6, marginBottom: 4, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Maya · barista</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, lineHeight: 1.3 }}>Hi! What can I get started for you?</div>
        </div>

        <div style={{
          padding: '14px 16px', borderRadius: 'var(--r-4)', background: 'var(--ocean-glow)',
          color: 'var(--ocean-deep)',
          alignSelf: 'flex-end', maxWidth: '85%', marginBottom: 8,
        }}>
          <div style={{ fontSize: 10, opacity: 0.7, marginBottom: 4, letterSpacing: '0.08em', textTransform: 'uppercase' }}>You · 4.2s</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 18, lineHeight: 1.3, fontStyle: 'italic' }}>
            "Can I get a large oat milk latte, please?"
          </div>
        </div>

        <div style={{ padding: '8px 14px', borderRadius: 'var(--r-pill)', background: 'rgba(134, 182, 146, 0.2)', alignSelf: 'flex-end', fontSize: 11, color: 'var(--moss-glow)', fontWeight: 600 }}>
          ✓ Clear · natural pace
        </div>

        <div style={{ marginTop: 'auto', textAlign: 'center' }}>
          <div style={{ display: 'flex', gap: 3, justifyContent: 'center', alignItems: 'center', marginBottom: 24, height: 48 }}>
            {[20, 35, 55, 80, 100, 75, 40, 60, 90, 70, 45, 30, 50, 65, 55, 25].map((h, i) => (
              <div key={i} style={{
                width: 4, height: `${h}%`,
                background: 'var(--ocean-glow)',
                borderRadius: 2,
                animation: `wave ${800 + i*40}ms ease-in-out infinite alternate`,
                animationDelay: `${i * 60}ms`,
              }}/>
            ))}
          </div>
          <div style={{
            width: 96, height: 96, margin: '0 auto', borderRadius: '50%',
            background: 'var(--ocean-glow)', color: 'var(--ocean-deep)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 0 0 16px rgba(109,184,204,0.15), 0 0 0 32px rgba(109,184,204,0.08)',
          }}>
            {React.cloneElement(Icons.mic, { style: { width: 36, height: 36, strokeWidth: 1.8 }, className: '' })}
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontStyle: 'italic', fontSize: 14, marginTop: 14, opacity: 0.85 }}>Listening…</div>
        </div>
      </div>
      <style>{`@keyframes wave { from { height: 20%; } to { height: 95%; } }`}</style>
    </div>
  );
}

/* ---------- QUIZ ---------- */
function ScreenQuiz() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--paper)' }}>
      <div style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ color: 'var(--text-2)' }}>{Icons.x}</div>
        <div style={{ flex: 1, display: 'flex', gap: 4 }}>
          {[1,2,3,4,5,6,7,8].map(i => (
            <div key={i} style={{ flex: 1, height: 4, borderRadius: 2, background: i <= 4 ? 'var(--indigo)' : 'var(--border)' }}/>
          ))}
        </div>
        <span className="mono" style={{ fontSize: 11, color: 'var(--text-3)' }}>4 / 8</span>
      </div>

      <div style={{ padding: '20px', flex: 1, display: 'flex', flexDirection: 'column' }}>
        <div className="eyebrow" style={{ marginBottom: 10 }}>Multi-select · pick all</div>
        <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 24, letterSpacing: '-0.02em', lineHeight: 1.15, marginBottom: 24 }}>
          Which of these reduce<br/><em style={{ fontStyle: 'italic', color: 'var(--indigo)' }}>hallucination</em> in LLMs?
        </h2>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[
            { t: 'Retrieval-augmented generation', checked: true },
            { t: 'Higher temperature', checked: false, wrong: true },
            { t: 'Grounding with citations', checked: true },
            { t: 'Chain-of-thought prompting', checked: false },
          ].map((o, i) => (
            <div key={i} style={{
              padding: 14,
              borderRadius: 'var(--r-3)',
              border: o.wrong ? '2px solid var(--coral)' : o.checked ? '2px solid var(--moss)' : '1px solid var(--border)',
              background: o.wrong ? 'var(--coral-soft)' : o.checked ? 'var(--moss-soft)' : 'var(--surface)',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{
                width: 22, height: 22, borderRadius: 6,
                border: o.checked || o.wrong ? 'none' : '2px solid var(--border-strong)',
                background: o.wrong ? 'var(--coral)' : o.checked ? 'var(--moss)' : 'transparent',
                color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {o.checked && React.cloneElement(Icons.check, { style: { width: 14, height: 14, strokeWidth: 2.5 }, className: '' })}
                {o.wrong && React.cloneElement(Icons.x, { style: { width: 14, height: 14, strokeWidth: 2.5 }, className: '' })}
              </div>
              <span style={{ fontSize: 14, fontWeight: 600, flex: 1, color: o.wrong ? 'var(--coral-deep)' : o.checked ? 'var(--moss-deep)' : 'var(--text)' }}>{o.t}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '12px 20px 18px' }}>
        <button className="btn btn--accent btn--lg" style={{ width: '100%' }}>Check answer</button>
      </div>
    </div>
  );
}

/* ---------- VIDEO ---------- */
function ScreenVideo() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--ink)', color: 'var(--paper)' }}>
      <div style={{
        flex: 1, background: 'linear-gradient(135deg, var(--saffron-deep) 0%, var(--coral-deep) 100%)',
        position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 60% 40%, rgba(242,198,113,0.3), transparent 50%)' }}/>
        <div style={{ position: 'absolute', top: 16, left: 16, right: 16, display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ color: 'var(--paper)' }}>{Icons.arrowLeft}</span>
          <div style={{ padding: '4px 10px', borderRadius: 999, background: 'rgba(0,0,0,0.3)', fontSize: 10, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase' }}>1.0×</div>
        </div>
        <div style={{ position: 'absolute', bottom: 20, left: 20, right: 20 }}>
          <div className="eyebrow" style={{ color: 'rgba(255,255,255,0.7)', marginBottom: 6 }}>Chapter 2</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.02em', lineHeight: 1.1 }}>
            How transformers<br/>actually pay attention.
          </div>
        </div>
        <div style={{
          position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
          width: 72, height: 72, borderRadius: '50%', background: 'rgba(255,255,255,0.95)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: 'var(--ink)',
        }}>
          {React.cloneElement(Icons.play, { style: { width: 28, height: 28, strokeWidth: 2, fill: 'var(--ink)' }, className: '' })}
        </div>
      </div>

      <div style={{ padding: '16px 20px', background: 'var(--ink)' }}>
        <div style={{ height: 3, background: 'rgba(255,255,255,0.15)', borderRadius: 2, position: 'relative', marginBottom: 8 }}>
          <div style={{ width: '38%', height: '100%', background: 'var(--saffron-glow)', borderRadius: 2 }}/>
          <div style={{ position: 'absolute', left: '38%', top: -4, width: 11, height: 11, borderRadius: '50%', background: 'var(--saffron-glow)', transform: 'translateX(-50%)' }}/>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, opacity: 0.7, fontFamily: 'var(--font-mono)' }}>
          <span>3:22</span><span>8:47</span>
        </div>
      </div>

      <div style={{ padding: '16px 20px', background: 'rgba(0,0,0,0.4)', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="eyebrow" style={{ color: 'rgba(255,255,255,0.6)', marginBottom: 6 }}>Live caption · EN</div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, lineHeight: 1.4, fontStyle: 'italic' }}>
          "…so each token looks at every other token, and decides <span style={{ background: 'var(--saffron)', color: 'var(--ink)', padding: '0 4px', borderRadius: 3 }}>how much</span> to listen to each one."
        </div>
      </div>
    </div>
  );
}

/* ---------- AUDIO CHAT ---------- */
function ScreenAudioChat() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'var(--paper)' }}>
      <div style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid var(--border)' }}>
        <div style={{ color: 'var(--text-2)' }}>{Icons.arrowLeft}</div>
        <div className="avatar" style={{ background: 'linear-gradient(135deg, var(--coral-soft), var(--saffron-soft))', color: 'var(--coral-deep)' }}>M</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 700 }}>Maya · AI tutor</div>
          <div style={{ fontSize: 11, color: 'var(--moss)', display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--moss)' }}/>Live · listening
          </div>
        </div>
        <div style={{ color: 'var(--text-2)' }}>{Icons.headphones}</div>
      </div>

      <div style={{ flex: 1, padding: '16px 20px', display: 'flex', flexDirection: 'column', gap: 12, overflow: 'hidden' }}>
        <div style={{ alignSelf: 'flex-start', maxWidth: '85%' }}>
          <div style={{ padding: 12, borderRadius: '4px 16px 16px 16px', background: 'var(--surface)', border: '1px solid var(--border)', fontSize: 13, lineHeight: 1.4 }}>
            Let's practice. Tell me about a project you're working on — one sentence.
          </div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--text-4)', marginTop: 4 }}>09:41 · 3.1s</div>
        </div>

        <div style={{ alignSelf: 'flex-end', maxWidth: '85%' }}>
          <div style={{ padding: 12, borderRadius: '16px 4px 16px 16px', background: 'var(--indigo)', color: '#fff', fontSize: 13, lineHeight: 1.4 }}>
            I'm building a voice agent that coaches runners during training.
          </div>
          <div className="mono" style={{ fontSize: 10, color: 'var(--text-4)', marginTop: 4, textAlign: 'right' }}>09:41 · you</div>
        </div>

        <div style={{ alignSelf: 'flex-start', maxWidth: '90%' }}>
          <div style={{ padding: 12, borderRadius: '4px 16px 16px 16px', background: 'var(--surface)', border: '1px solid var(--border)', fontSize: 13, lineHeight: 1.5 }}>
            Nice. Two quick follow-ups: <span style={{ color: 'var(--indigo)', fontWeight: 600 }}>①</span> Who's it for, runners new or experienced? <span style={{ color: 'var(--indigo)', fontWeight: 600 }}>②</span> Does it run during or after the run?
          </div>
          <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
            <span className="chip chip--indigo" style={{ fontSize: 10, padding: '3px 8px' }}>Rephrase</span>
            <span className="chip" style={{ fontSize: 10, padding: '3px 8px' }}>Translate</span>
            <span className="chip" style={{ fontSize: 10, padding: '3px 8px' }}>Save</span>
          </div>
        </div>
      </div>

      <div style={{ padding: '12px 16px', borderTop: '1px solid var(--border)', background: 'var(--surface)', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ color: 'var(--text-3)' }}>{Icons.plus}</div>
        <div style={{ flex: 1, padding: '10px 14px', borderRadius: 999, background: 'var(--bg-soft)', border: '1px solid var(--border)', fontSize: 13, color: 'var(--text-4)' }}>Hold to speak · or type</div>
        <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'var(--ocean)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 0 var(--ocean-deep)' }}>
          {Icons.mic}
        </div>
      </div>
    </div>
  );
}

/* ---------- AVATAR ---------- */
function ScreenAvatar() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'linear-gradient(180deg, var(--plum-deep) 0%, var(--indigo-deep) 100%)', color: 'var(--paper)' }}>
      <div style={{ padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ color: 'var(--paper)' }}>{Icons.arrowLeft}</div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', opacity: 0.7 }}>Avatar · roleplay</div>
          <div style={{ fontSize: 14, fontWeight: 600 }}>Job interview · Staff PM</div>
        </div>
        <div style={{ color: 'var(--paper)' }}>{Icons.more}</div>
      </div>

      <div style={{ flex: 1, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 40%, rgba(196,141,198,0.3), transparent 55%)' }}/>
        {/* Avatar portrait placeholder */}
        <div style={{
          position: 'relative', width: 200, height: 200,
          borderRadius: '50%',
          background: 'linear-gradient(135deg, var(--plum-glow) 0%, var(--indigo-glow) 100%)',
          border: '3px solid rgba(255,255,255,0.2)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 0 0 24px rgba(255,255,255,0.04), 0 0 0 48px rgba(255,255,255,0.02)',
        }}>
          <svg viewBox="0 0 80 80" width="120" height="120">
            <circle cx="40" cy="30" r="14" fill="rgba(255,255,255,0.8)"/>
            <path d="M 14 70 Q 40 48 66 70 L 66 80 L 14 80 Z" fill="rgba(255,255,255,0.8)"/>
          </svg>
          <div style={{
            position: 'absolute', bottom: 8, right: 8,
            width: 20, height: 20, borderRadius: '50%', background: 'var(--moss)',
            border: '3px solid var(--plum-deep)',
          }}/>
        </div>
      </div>

      <div style={{ padding: '16px 20px', background: 'rgba(0,0,0,0.3)', backdropFilter: 'blur(20px)', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="eyebrow" style={{ color: 'rgba(255,255,255,0.6)', marginBottom: 6 }}>Maya · interviewer</div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontStyle: 'italic', lineHeight: 1.4, marginBottom: 16 }}>
          "Walk me through a time you had to ship something with <span style={{ color: 'var(--plum-glow)' }}>incomplete information.</span>"
        </div>

        <div style={{ display: 'flex', justifyContent: 'center', gap: 14 }}>
          <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{Icons.volume}</div>
          <div style={{
            width: 72, height: 72, borderRadius: '50%', background: 'var(--coral)', color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 0 0 8px rgba(240,139,113,0.2)',
          }}>
            {React.cloneElement(Icons.mic, { style: { width: 28, height: 28 }, className: '' })}
          </div>
          <div style={{ width: 48, height: 48, borderRadius: '50%', background: 'rgba(255,255,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{Icons.x}</div>
        </div>
      </div>
    </div>
  );
}

/* ---------- STREAK / REWARD ---------- */
function ScreenStreak() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, background: 'linear-gradient(180deg, var(--saffron-soft) 0%, var(--paper) 60%)', padding: '32px 24px', alignItems: 'center', textAlign: 'center' }}>
      <div style={{ color: 'var(--saffron-deep)', marginBottom: 12 }}>
        {React.cloneElement(Icons.flame, { style: { width: 64, height: 64, strokeWidth: 1.2 }, className: '' })}
      </div>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 72, letterSpacing: '-0.04em', lineHeight: 1, color: 'var(--saffron-deep)', fontWeight: 300 }}>12</h2>
      <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--saffron-deep)', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 20 }}>Day streak</div>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, letterSpacing: '-0.02em', lineHeight: 1.2, fontStyle: 'italic', marginBottom: 24, maxWidth: 280 }}>
        "Twelve quiet mornings. Keep going."
      </div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 32, flexWrap: 'wrap', justifyContent: 'center' }}>
        {['M','T','W','T','F','S','S'].map((d, i) => (
          <div key={i} style={{
            width: 36, height: 48, borderRadius: 'var(--r-3)',
            background: i < 5 ? 'var(--saffron)' : i === 5 ? 'var(--saffron-glow)' : 'var(--surface)',
            border: '1px solid var(--saffron-deep)',
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            color: i < 6 ? 'var(--saffron-deep)' : 'var(--text-4)',
          }}>
            <div style={{ fontSize: 10, fontWeight: 700 }}>{d}</div>
            <div style={{ fontSize: 14 }}>{i < 5 ? '✓' : i === 5 ? '★' : '·'}</div>
          </div>
        ))}
      </div>
      <div style={{ padding: 16, borderRadius: 'var(--r-4)', background: 'var(--surface)', border: '1px solid var(--border)', width: '100%', marginBottom: 16 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 8 }}>
          <span style={{ fontWeight: 600 }}>Next reward · 14 days</span>
          <span className="mono" style={{ color: 'var(--text-3)' }}>12 / 14</span>
        </div>
        <div className="progress progress--saffron"><div className="progress__fill" style={{ width: '86%', background: 'linear-gradient(90deg, var(--saffron), var(--saffron-glow))' }}/></div>
      </div>
      <button className="btn btn--accent btn--lg btn--pill" style={{ width: '100%', background: 'var(--saffron-deep)', boxShadow: '0 2px 0 #6b480a' }}>Keep the streak alive</button>
    </div>
  );
}

Object.assign(window, {
  PhoneFrame, ScreenOnboarding, ScreenHome, ScreenLesson, ScreenVoice,
  ScreenQuiz, ScreenVideo, ScreenAudioChat, ScreenAvatar, ScreenStreak,
});
